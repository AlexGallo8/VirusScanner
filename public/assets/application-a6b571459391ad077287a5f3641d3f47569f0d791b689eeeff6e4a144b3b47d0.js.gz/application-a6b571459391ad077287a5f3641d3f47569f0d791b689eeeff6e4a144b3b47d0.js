// Import jQuery
import jquery from 'jquery'
window.jQuery = jquery
window.$ = jquery

// Import your scripts
//= require_tree .
//= require scripts


;
