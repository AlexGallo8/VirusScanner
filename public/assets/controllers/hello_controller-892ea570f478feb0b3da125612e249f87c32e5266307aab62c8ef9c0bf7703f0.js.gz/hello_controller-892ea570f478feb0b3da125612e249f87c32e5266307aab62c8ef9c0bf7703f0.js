// import { Controller } from "@hotwired/stimulus"

// export default class extends Controller {
//   connect() {
//     console.log("Hello Controller connected")
//   }
// }

export const setupClerkEvents = () => {
  // Your Clerk event handling code here
  console.log("Clerk events initialized")
};
